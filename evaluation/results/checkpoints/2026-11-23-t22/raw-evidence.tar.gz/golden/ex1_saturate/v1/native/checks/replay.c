#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include "frame.h"
#define __CPROVER_assume(c) do { if (!(c)) exit(77); } while (0)
#define __CPROVER_assert(c,m) do { if (!(c)) exit(77); } while (0)
void __vwe_a0_call(const struct __vwe_input *in, struct __vwe_output *out);
void __vwe_a1_call(const struct __vwe_input *in, struct __vwe_output *out);
/* VE-DSL-1 observer: V-G/old-definedness checks are still required. */
static inline int vwe_observer_0(unsigned char ve_arg_0, unsigned char ve_arg_1, unsigned char ve_arg_2) {
  long long ve_t_0 = ((((long long)ve_arg_0)) + (((long long)ve_arg_1)));
  long long ve_t_1 = (255LL);
  return ((((long long)ve_arg_2)) == ((ve_t_0 < ve_t_1 ? ve_t_0 : ve_t_1)));
}
/* VE-DSL-1 observer: V-G/old-definedness checks are still required. */
static inline int vwe_observer_1(unsigned char ve_arg_0) {
  return ((((long long)ve_arg_0)) == ((255LL)));
}
/* VE-DSL-1 observer: V-G/old-definedness checks are still required. */
static inline int vwe_observer_2(unsigned char ve_arg_0, unsigned char ve_arg_1) {
  return ((((((long long)ve_arg_0)) + (((long long)ve_arg_1)))) > ((255LL)));
}
/* VE-DSL-1 observer: V-G/old-definedness checks are still required. */
static inline int vwe_observer_3(unsigned char ve_arg_0, unsigned char ve_arg_1) {
  return ((((((long long)ve_arg_0)) + (((long long)ve_arg_1)))) > ((255LL)));
}
/* VE-DSL-1 observer: V-G/old-definedness checks are still required. */
static inline int vwe_observer_4(unsigned char ve_arg_0, unsigned char ve_arg_1) {
  return ((((((long long)ve_arg_0)) + (((long long)ve_arg_1)))) > ((255LL)));
}
/* VE-DSL-1 observer: V-G/old-definedness checks are still required. */
static inline int vwe_observer_5(unsigned char ve_arg_0, unsigned char ve_arg_1) {
  return ((((((long long)ve_arg_0)) + (((long long)ve_arg_1)))) > ((255LL)));
}
/* VE-DSL-1 observer: V-G/old-definedness checks are still required. */
static inline int vwe_observer_6(unsigned char ve_arg_0, unsigned char ve_arg_1, unsigned char ve_arg_2) {
  long long ve_t_0 = ((((long long)ve_arg_0)) + (((long long)ve_arg_1)));
  long long ve_t_1 = (255LL);
  return ((((long long)ve_arg_2)) == ((ve_t_0 < ve_t_1 ? ve_t_0 : ve_t_1)));
}
/* VE-DSL-1 observer: V-G/old-definedness checks are still required. */
static inline int vwe_observer_7(unsigned char ve_arg_0, unsigned char ve_arg_1) {
  return ((((((long long)ve_arg_0)) + (((long long)ve_arg_1)))) > ((255LL)));
}
/* VE-DSL-1 observer: V-G/old-definedness checks are still required. */
static inline int vwe_observer_8(unsigned char ve_arg_0, unsigned char ve_arg_1) {
  return ((((((long long)ve_arg_0)) + (((long long)ve_arg_1)))) > ((255LL)));
}
/* VE-DSL-1 observer: V-G/old-definedness checks are still required. */
static inline int vwe_observer_9(unsigned char ve_arg_0) {
  return ((((long long)ve_arg_0)) == ((255LL)));
}

int main(int argc, char **argv) {
  if (argc != 3) return 77;
  char *__vwe_end;
  struct __vwe_input __vwe_in={0};
  errno=0;
  unsigned long long __vwe_native_value_1=strtoull(argv[1], &__vwe_end, 10);
  if (errno || __vwe_end==argv[1] || *__vwe_end || __vwe_native_value_1 < 0LL || __vwe_native_value_1 > 255LL) return 77;
  unsigned char __vwe_in_scalar_0_0=(unsigned char)__vwe_native_value_1;
  __vwe_in.s0_0=__vwe_in_scalar_0_0;
  errno=0;
  unsigned long long __vwe_native_value_2=strtoull(argv[2], &__vwe_end, 10);
  if (errno || __vwe_end==argv[2] || *__vwe_end || __vwe_native_value_2 < 0LL || __vwe_native_value_2 > 255LL) return 77;
  unsigned char __vwe_in_scalar_1_0=(unsigned char)__vwe_native_value_2;
  __vwe_in.s1_0=__vwe_in_scalar_1_0;
  struct __vwe_output __vwe_one={0};
  struct __vwe_output __vwe_zero={0};
  __vwe_a1_call(&__vwe_in, &__vwe_one);
  if (!(vwe_observer_2(__vwe_in_scalar_0_0, __vwe_in_scalar_1_0)) || !(vwe_observer_3(__vwe_in_scalar_0_0, __vwe_in_scalar_1_0))) {
  __vwe_a0_call(&__vwe_in, &__vwe_zero);
  }
  printf("%s\t%lld\n", "__vwe_check_0", (long long)(((vwe_observer_4(__vwe_in_scalar_0_0, __vwe_in_scalar_1_0)) || ((__vwe_zero.r0==__vwe_one.r0))) && (((!(vwe_observer_5(__vwe_in_scalar_0_0, __vwe_in_scalar_1_0)) || (vwe_observer_6(__vwe_in_scalar_0_0, __vwe_in_scalar_1_0, __vwe_one.r0)))))));
  printf("%s\t%lld\n", "__vwe_check_1", (long long)(((vwe_observer_7(__vwe_in_scalar_0_0, __vwe_in_scalar_1_0)) || ((__vwe_zero.r0==__vwe_one.r0))) && (((!(vwe_observer_8(__vwe_in_scalar_0_0, __vwe_in_scalar_1_0)) || (vwe_observer_9(__vwe_one.r0)))))));
  printf("%s\t%llu\n", "ret", (unsigned long long)(__vwe_one.r0));
  return 0;
}

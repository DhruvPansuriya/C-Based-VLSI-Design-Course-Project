#undef __SYNTHESIS__
#define __SYNTHESIS__ 1
#line 1 "input.c"
unsigned char add8(unsigned char a, unsigned char b) { unsigned char s=(unsigned char)(a+b); return s<a ? 255u : s; }

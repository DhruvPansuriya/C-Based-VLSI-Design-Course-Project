#undef __SYNTHESIS__

#line 1 "input.c"
unsigned char add8(unsigned char a, unsigned char b) { unsigned char s=(unsigned char)(a+b); return s<a ? 255u : s; }

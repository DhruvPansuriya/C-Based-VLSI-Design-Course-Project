# 1 "unit.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 484 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "unit.c" 2
# 1 "input.c"
unsigned char add8(unsigned char a, unsigned char b) { unsigned s=(unsigned)a+(unsigned)b; return s>255u ? 255u : (unsigned char)s; }
